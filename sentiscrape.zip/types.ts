
export interface SentimentData {
  date: string;
  ticker: string;
  totalCount: number;
  positiveCount: number;
  negativeCount: number;
  organicPositiveCount: number;
  organicNegativeCount: number;
}
