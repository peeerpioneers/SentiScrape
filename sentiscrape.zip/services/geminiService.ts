
import { GoogleGenAI, Type } from "@google/genai";
import type { SentimentData } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const sentimentSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      date: {
        type: Type.STRING,
        description: 'The date for the sentiment data in YYYY-MM-DD format.',
      },
      ticker: {
        type: Type.STRING,
        description: 'The stock ticker symbol provided by the user.',
      },
      totalCount: {
        type: Type.INTEGER,
        description: 'The total number of comments or engagements for that day. Should be a realistic number, ranging from a few dozen to a few thousand for popular stocks.'
      },
      positiveCount: {
        type: Type.INTEGER,
        description: 'The number of positive comments/engagements. This plus negativeCount should not exceed totalCount.',
      },
      negativeCount: {
        type: Type.INTEGER,
        description: 'The number of negative comments/engagements. This plus positiveCount should not exceed totalCount.',
      },
      organicPositiveCount: {
        type: Type.INTEGER,
        description: 'The estimated number of positive comments after filtering out suspected bots and repetitive promoters. This should be less than or equal to positiveCount.',
      },
      organicNegativeCount: {
        type: Type.INTEGER,
        description: 'The estimated number of negative comments after filtering out suspected bots and repetitive bashers. This should be less than or equal to negativeCount.',
      },
    },
    required: ["date", "ticker", "totalCount", "positiveCount", "negativeCount", "organicPositiveCount", "organicNegativeCount"],
  },
};

export const fetchSentimentData = async (ticker: string): Promise<SentimentData[]> => {
  const today = new Date();
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(today.getDate() - 30);
  const todayStr = today.toISOString().split('T')[0];
  const thirtyDaysAgoStr = thirtyDaysAgo.toISOString().split('T')[0];

  const prompt = `
    Generate a JSON array of simulated daily sentiment data for the stock ticker "${ticker.toUpperCase()}" for the last 30 days, from ${thirtyDaysAgoStr} to ${todayStr}.
    Each object in the array should represent one day and contain the date, the ticker symbol, a total sentiment count, a positive sentiment count, and a negative sentiment count.
    
    To provide a more accurate picture, also generate 'organic' sentiment counts. The organic counts should represent the sentiment after theoretically filtering out low-quality, repetitive, or bot-like comments (bashers and promoters).
    Therefore, 'organicPositiveCount' must be less than or equal to 'positiveCount', and 'organicNegativeCount' must be less than or equal to 'negativeCount'. This simulates a 'weeding out' of inorganic activity to get a clearer signal.

    The sentiment counts should be plausible for a stock's community engagement. Ensure the sum of positive and negative counts is less than or equal to the total count.
    If the ticker symbol seems invalid or is not a real stock, return an empty array.
    Sort the results by date in descending order (most recent first).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: sentimentSchema,
      },
    });
    
    const jsonStr = response.text;
    const data = JSON.parse(jsonStr);

    if (!Array.isArray(data)) {
        throw new Error("Invalid data format received from API.");
    }
    
    // Additional validation to ensure data matches the expected shape
    const validatedData = data.filter(item => 
      typeof item.date === 'string' &&
      typeof item.ticker === 'string' &&
      typeof item.totalCount === 'number' &&
      typeof item.positiveCount === 'number' &&
      typeof item.negativeCount === 'number' &&
      typeof item.organicPositiveCount === 'number' &&
      typeof item.organicNegativeCount === 'number'
    );
    
    return validatedData as SentimentData[];

  } catch (error) {
    console.error("Error fetching sentiment data from Gemini API:", error);
    throw new Error("Failed to generate sentiment data. The API may be unavailable or the request failed.");
  }
};
