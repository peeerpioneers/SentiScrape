
import React, { useState } from 'react';

interface TickerInputProps {
  onFetch: (ticker: string) => void;
  isLoading: boolean;
}

export const TickerInput: React.FC<TickerInputProps> = ({ onFetch, isLoading }) => {
  const [ticker, setTicker] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ticker.trim()) {
      onFetch(ticker.trim());
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-slate-800/50 p-6 rounded-xl shadow-2xl border border-slate-700">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-4">
        <label htmlFor="ticker-input" className="sr-only">Stock Ticker</label>
        <input
          id="ticker-input"
          type="text"
          value={ticker}
          onChange={(e) => setTicker(e.target.value.toUpperCase())}
          placeholder="Enter Ticker (e.g., TSLA)"
          className="w-full sm:flex-grow px-4 py-3 bg-slate-900 border-2 border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 text-lg"
          disabled={isLoading}
        />
        <button
          type="submit"
          className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:from-cyan-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-blue-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-lg flex items-center justify-center gap-2"
          disabled={isLoading}
        >
          {isLoading ? 'Analyzing...' : 'Get Sentiment'}
        </button>
      </form>
    </div>
  );
};
