
import React from 'react';

export const InitialStateMessage: React.FC = () => {
  return (
    <div className="text-center p-8 bg-slate-800/50 border border-slate-700 rounded-xl">
      <h3 className="text-xl font-semibold text-slate-300">Ready to Analyze</h3>
      <p className="text-slate-400 mt-2">
        Enter a stock ticker symbol above to generate and view its community sentiment data for the last 30 days.
      </p>
    </div>
  );
};
