
import React, { useState, useMemo } from 'react';
import type { SentimentData } from '../types';

interface SentimentTableProps {
  data: SentimentData[];
}

type SortKey = keyof SentimentData | 'priceDirection';
type SortDirection = 'ascending' | 'descending';

interface SortConfig {
  key: SortKey;
  direction: SortDirection;
}

const getPriceDirectionValue = (item: SentimentData): number => {
    // Use organic counts for a cleaner signal
    const totalSentiment = item.organicPositiveCount + item.organicNegativeCount;
    if (totalSentiment === 0) {
      return 50; // Treat as neutral for sorting
    }
    return (item.organicPositiveCount / totalSentiment) * 100;
  };


export const SentimentTable: React.FC<SentimentTableProps> = ({ data }) => {
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'date', direction: 'descending' });

  if (!data || data.length === 0) {
    return <p className="text-center text-slate-400">No data available.</p>;
  }
  
  const currentTicker = data[0]?.ticker || '';

  const sortedData = useMemo(() => {
    const sortableItems = [...data];
    sortableItems.sort((a, b) => {
      let aValue: string | number;
      let bValue: string | number;

      if (sortConfig.key === 'priceDirection') {
        aValue = getPriceDirectionValue(a);
        bValue = getPriceDirectionValue(b);
      } else {
        aValue = a[sortConfig.key as keyof SentimentData];
        bValue = b[sortConfig.key as keyof SentimentData];
      }
      
      if (aValue < bValue) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });
    return sortableItems;
  }, [data, sortConfig]);

  const requestSort = (key: SortKey) => {
    let direction: SortDirection = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  const getSortIndicator = (key: SortKey) => {
    if (sortConfig.key !== key) {
      return null;
    }
    return sortConfig.direction === 'ascending' ? '▲' : '▼';
  };
  
  const renderPriceDirection = (organicPositive: number, organicNegative: number) => {
    const totalSentiment = organicPositive + organicNegative;

    if (totalSentiment === 0) {
      return (
        <span className="flex items-center justify-end gap-2 font-medium text-slate-500" title="No organic positive or negative sentiment data available">
          <span>—</span>
          <span>N/A</span>
        </span>
      );
    }

    const probabilityUp = (organicPositive / totalSentiment) * 100;

    if (probabilityUp > 50) {
      return (
        <span className="flex items-center justify-end gap-2 font-medium text-green-400" title={`${probabilityUp.toFixed(1)}% probability of upward movement based on organic sentiment`}>
          <span>▲</span>
          <span>{probabilityUp.toFixed(1)}%</span>
        </span>
      );
    } else if (probabilityUp < 50) {
      const probabilityDown = 100 - probabilityUp;
      return (
        <span className="flex items-center justify-end gap-2 font-medium text-red-400" title={`${probabilityDown.toFixed(1)}% probability of downward movement based on organic sentiment`}>
          <span>▼</span>
          <span>{probabilityUp.toFixed(1)}%</span>
        </span>
      );
    } else { // Exactly 50%
      return (
        <span className="flex items-center justify-end gap-2 font-medium text-slate-400" title="Neutral organic sentiment">
          <span>—</span>
          <span>50.0%</span>
        </span>
      );
    }
  };

  const headerCellClasses = "p-4 text-sm font-semibold text-slate-300 uppercase tracking-wider";
  const sortableHeaderClasses = "cursor-pointer hover:bg-slate-700/50 transition-colors duration-200";

  const renderHeader = (key: SortKey, label: string, alignment: 'left' | 'right' = 'left', tooltip: string = '') => {
    const isSorted = sortConfig.key === key;
    return (
        <th 
            className={`${headerCellClasses} ${sortableHeaderClasses} text-${alignment}`}
            onClick={() => requestSort(key)}
            aria-sort={isSorted ? sortConfig.direction : 'none'}
            title={tooltip}
        >
            <div className={`flex items-center gap-2 ${alignment === 'right' ? 'justify-end' : ''}`}>
                <span>{label}</span>
                {isSorted && <span className="text-cyan-400">{getSortIndicator(key)}</span>}
            </div>
        </th>
    );
  }

  return (
    <div className="bg-slate-800/50 rounded-xl shadow-2xl border border-slate-700 overflow-hidden">
      <h2 className="text-2xl font-bold text-center p-6 bg-slate-800">
        Sentiment Analysis for <span className="text-cyan-400">{currentTicker}</span>
      </h2>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[950px] text-left">
          <thead className="bg-slate-900/70">
            <tr>
              {renderHeader('date', 'Date')}
              {renderHeader('ticker', 'Ticker')}
              {renderHeader('totalCount', 'Total Comments', 'right')}
              {renderHeader('positiveCount', 'Positive', 'right')}
              {renderHeader('negativeCount', 'Negative', 'right')}
              {renderHeader('organicPositiveCount', 'Organic Pos.', 'right', 'Sentiment after filtering out simulated bot/spam activity.')}
              {renderHeader('organicNegativeCount', 'Organic Neg.', 'right', 'Sentiment after filtering out simulated bot/spam activity.')}
              {renderHeader('priceDirection', 'Price Direction', 'right')}
            </tr>
          </thead>
          <tbody>
            {sortedData.map((item) => (
              <tr key={item.date} className="border-t border-slate-700 hover:bg-slate-700/50 transition-colors duration-200">
                <td className="p-4 whitespace-nowrap">{item.date}</td>
                <td className="p-4 whitespace-nowrap font-mono text-cyan-400">{item.ticker}</td>
                <td className="p-4 whitespace-nowrap text-right font-medium">{item.totalCount.toLocaleString()}</td>
                <td className="p-4 whitespace-nowrap text-right font-medium text-green-500/80">{item.positiveCount.toLocaleString()}</td>
                <td className="p-4 whitespace-nowrap text-right font-medium text-red-500/80">{item.negativeCount.toLocaleString()}</td>
                <td className="p-4 whitespace-nowrap text-right font-bold text-green-400">{item.organicPositiveCount.toLocaleString()}</td>
                <td className="p-4 whitespace-nowrap text-right font-bold text-red-400">{item.organicNegativeCount.toLocaleString()}</td>
                <td className="p-4 whitespace-nowrap text-right">
                  {renderPriceDirection(item.organicPositiveCount, item.organicNegativeCount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
