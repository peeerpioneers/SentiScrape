
import React from 'react';

interface LoadingSpinnerProps {
  ticker: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ ticker }) => {
  return (
    <div className="flex flex-col items-center justify-center gap-4 p-8 text-slate-400">
      <div className="w-12 h-12 border-4 border-slate-600 border-t-cyan-400 rounded-full animate-spin"></div>
      <p className="text-lg font-semibold">Analyzing sentiment for ${ticker}...</p>
      <p className="text-sm">This may take a moment.</p>
    </div>
  );
};
